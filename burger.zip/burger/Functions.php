<?php

function register_my_menus() {
  register_nav_menus(
    array(
      'header-menu' => __( 'Nav Header Menu' ),
     
    )
  );
}
add_action( 'init', 'register_my_menus' );


function ourWidgetsInit(){
	register_sidebar(array (
	
	'id' => 'sidebar1',
	'before_widget' => '<div class ="sidebar">',
	'name' => 'footcol1'
	));
}

add_action( 'widgets_init', 'ourWidgetsInit' );




function ourWidgets1Init(){
	register_sidebar(array (
	
	'id' => 'sidebar2',
	'before_widget' => '<div class ="sidebar">',
	'name' => 'footcol2'
	));
}

add_action( 'widgets_init', 'ourWidgets1Init' );


?>