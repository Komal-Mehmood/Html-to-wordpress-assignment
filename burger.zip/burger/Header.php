<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/stylesheet.css">

    <title> <?php bloginfo('name');?></title>
  </head>
  <body>
  <header>

<?php dynamic_sidebar('logo');
?>

<div class = "col2">


   <nav class="navbar navbar-expand-lg navbar-light bg-light bg-transparent container-fluid">
  <div class="row w-100">
   
  <div class="col-md-4">
 
  <a class="navbar-brand" href="#"> <img src="<?php echo get_template_directory_uri();?>/images/logo.png"></a>
  
  </div>
  <div class="col-md-8">
  <div class="phone-number  text-right"> 
   <img src="<?php echo get_template_directory_uri();?>/images/bike-icon.png">Express Delivery +12345678
   </div>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  <nav class = "navbar-nav ml-auto main-nav">
		<?php wp_nav_menu( array( 'theme_location' => 'primary_menu',
									'container_class' => 'MyHeaderNav' ) ); 
									?>
</nav> 
 </div>
  </div>
  </div>
  
  
</nav>

<img src="<?php echo get_template_directory_uri();?>/images/slider-bg.png" width="100%" height = "300px">
 
</header>