 <!-- Bootstrap CSS -->
    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/stylesheet.css">
<section>
	<div class="footerMain1">
		<img src = "<?php echo get_template_directory_uri();?>/images/footer-bg.png" width="100%" height = "500px">
	
	
		<div class="ColLeft">
			<?php dynamic_sidebar('sidebar1')?>
		</div>
	
	
		<div class="ColRight">
			<?php dynamic_sidebar('sidebar2')?>
		</div>
	
 
 </div>
 
</section>

     <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="<?php echo get_template_directory_uri();?>/bootstrap.min.js"></script>

  </body>
</html>